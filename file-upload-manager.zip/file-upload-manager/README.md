
# File Upload Manager
Simple File Upload Manager using Node.js, Express and Multer.

Features:
- Upload single or multiple files
- List uploaded files
- Download files
- Delete files
- Simple responsive frontend (served by Express)

## How to run
1. Install Node.js (v14+ recommended).
2. In the project folder run:
   ```
   npm install
   node server.js
   ```
3. Open http://localhost:3000 in your browser.

## Project structure
- server.js         - Express server and API
- package.json      - npm metadata
- public/index.html - Frontend UI
- public/app.js     - Frontend JS
- uploads/          - Stored uploaded files (created at runtime)
- .gitignore        - ignores node_modules and uploads
