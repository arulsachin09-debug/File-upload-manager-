
const express = require('express');
const multer  = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure uploads folder exists
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// Multer setup: store files in uploads, keep original filename
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    // add timestamp to avoid name collisions
    const ts = Date.now();
    const safe = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, '_');
    cb(null, `${ts}-${safe}`);
  }
});
const upload = multer({ storage });

// Serve frontend
app.use(express.static(path.join(__dirname, 'public')));

// API: upload single file
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  res.json({ ok: true, file: req.file.filename });
});

// API: upload multiple files
app.post('/api/upload-multiple', upload.array('files', 20), (req, res) => {
  if (!req.files || req.files.length === 0) return res.status(400).json({ error: 'No files uploaded' });
  res.json({ ok: true, files: req.files.map(f => f.filename) });
});

// API: list files
app.get('/api/files', (req, res) => {
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) return res.status(500).json({ error: 'Unable to list files' });
    // return name and size and created time
    const list = files.map(name => {
      const p = path.join(UPLOAD_DIR, name);
      const s = fs.statSync(p);
      return { name, size: s.size, mtime: s.mtime };
    }).sort((a,b)=>b.mtime - a.mtime);
    res.json(list);
  });
});

// API: download file
app.get('/api/files/:name', (req, res) => {
  const name = req.params.name;
  const filePath = path.join(UPLOAD_DIR, path.basename(name));
  if (!fs.existsSync(filePath)) return res.status(404).send('File not found');
  res.download(filePath);
});

// API: delete file
app.delete('/api/files/:name', (req, res) => {
  const name = req.params.name;
  const filePath = path.join(UPLOAD_DIR, path.basename(name));
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Not found' });
  fs.unlink(filePath, (err) => {
    if (err) return res.status(500).json({ error: 'Delete failed' });
    res.json({ ok: true });
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`File Upload Manager listening on http://localhost:${PORT}`);
});
