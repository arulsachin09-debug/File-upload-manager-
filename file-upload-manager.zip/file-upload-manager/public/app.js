
async function fetchFiles(){
  const res = await fetch('/api/files');
  const files = await res.json();
  const cont = document.getElementById('filesContainer');
  if (!files || files.length === 0) {
    cont.innerHTML = '<p class="muted">No files uploaded yet.</p>';
    return;
  }
  let html = '<table><thead><tr><th>Name</th><th>Size</th><th>Modified</th><th>Actions</th></tr></thead><tbody>';
  for (const f of files){
    const sizeKb = (f.size/1024).toFixed(2) + ' KB';
    const m = new Date(f.mtime).toLocaleString();
    html += `<tr><td style="max-width:350px;word-break:break-all">${f.name}</td><td>${sizeKb}</td><td>${m}</td>
      <td>
        <a href="/api/files/${encodeURIComponent(f.name)}" download><button>Download</button></a>
        <button data-name="${f.name}" class="del">Delete</button>
      </td></tr>`;
  }
  html += '</tbody></table>';
  cont.innerHTML = html;
  document.querySelectorAll('.del').forEach(b=>{
    b.onclick = async e=>{
      const name = e.currentTarget.dataset.name;
      if (!confirm('Delete '+name+'?')) return;
      const res = await fetch('/api/files/'+encodeURIComponent(name), { method:'DELETE' });
      if (res.ok) fetchFiles();
      else alert('Delete failed');
    };
  });
}

document.getElementById('uploadForm').onsubmit = async (e)=>{
  e.preventDefault();
  const input = document.getElementById('fileInput');
  if (!input.files.length) return alert('Choose a file');
  const fd = new FormData();
  fd.append('file', input.files[0]);
  const res = await fetch('/api/upload', { method:'POST', body: fd });
  const js = await res.json();
  if (res.ok) {
    input.value = '';
    fetchFiles();
  } else {
    alert(js.error || 'Upload failed');
  }
};

document.getElementById('multiForm').onsubmit = async (e)=>{
  e.preventDefault();
  const input = document.getElementById('multiInput');
  if (!input.files.length) return alert('Choose files');
  const fd = new FormData();
  for (let i=0;i<input.files.length;i++) fd.append('files', input.files[i]);
  const res = await fetch('/api/upload-multiple', { method:'POST', body: fd });
  const js = await res.json();
  if (res.ok) {
    input.value = '';
    fetchFiles();
  } else {
    alert(js.error || 'Upload failed');
  }
};

fetchFiles();
